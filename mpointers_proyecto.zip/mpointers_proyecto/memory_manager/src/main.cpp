#include <iostream>
#include <string>
#include <grpcpp/grpcpp.h>
#include "memory_manager.grpc.pb.h"

// Implementación de la lógica del Memory Manager
class MemoryManagerServiceImpl final : public memory::MemoryManager::Service {
public:
    grpc::Status Create(grpc::ServerContext* context, const memory::CreateRequest* request,
                        memory::CreateResponse* response) override {
        // Lógica para reservar un bloque de memoria
        int id = 1; // Ejemplo: generar un ID simple
        response->set_id(id);
        std::cout << "Creando bloque de tamaño: " << request->size() << std::endl;
        return grpc::Status::OK;
    }
    // Implementa Set, Get, IncreaseRefCount y DecreaseRefCount de forma similar.
};

int main(int argc, char** argv) {
    std::string server_address("0.0.0.0:50051");
    MemoryManagerServiceImpl service;

    grpc::ServerBuilder builder;
    builder.AddListeningPort(server_address, grpc::InsecureServerCredentials());
    builder.RegisterService(&service);

    std::unique_ptr<grpc::Server> server(builder.BuildAndStart());
    std::cout << "Servidor escuchando en " << server_address << std::endl;

    server->Wait();
    return 0;
}
