#include <iostream>
#include <string>
#include <grpcpp/grpcpp.h>
#include "memory_manager.grpc.pb.h"
#include <memory>
#include "memory_manager_service.h"

using grpc::Channel;
using grpc::ClientContext;
using grpc::Status;

    int main(int argc, char** argv) {
        std::string server_address("0.0.0.0:50051");
        MemoryManagerServiceImpl service;
    
        grpc::ServerBuilder builder;
        builder.AddListeningPort(server_address, grpc::InsecureServerCredentials());
        builder.RegisterService(&service);
        std::unique_ptr<grpc::Server> server(builder.BuildAndStart());
    
        std::cout << "Servidor escuchando en " << server_address << std::endl;
        server->Wait();
        return 0;
    }
    