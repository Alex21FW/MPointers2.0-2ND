#ifndef MEMORY_MANAGER_SERVICE_H
#define MEMORY_MANAGER_SERVICE_H

#include <grpcpp/grpcpp.h>
#include "memory_manager.grpc.pb.h"  // Define la clase memory::MemoryManager
#include <unordered_map>

struct MemoryBlock {
    int id;
    int size;
    std::string type;
    std::string data;
    int ref_count;
};

// Declaración de la clase
class MemoryManagerServiceImpl final : public memory::MemoryManager::Service {
    public:
        grpc::Status Create(grpc::ServerContext*, const memory::CreateRequest*, memory::CreateResponse*) override;
        grpc::Status Set(grpc::ServerContext*, const memory::SetRequest*, memory::SetResponse*) override;
        grpc::Status Get(grpc::ServerContext*, const memory::GetRequest*, memory::GetResponse*) override;
        grpc::Status IncreaseRefCount(grpc::ServerContext*, const memory::RefCountRequest*, memory::RefCountResponse*) override;
        grpc::Status DecreaseRefCount(grpc::ServerContext*, const memory::RefCountRequest*, memory::RefCountResponse*) override;
    
    private:
        std::unordered_map<int, MemoryBlock> memory_blocks_;
        int next_id_ = 1;
    };
    
    #endif
