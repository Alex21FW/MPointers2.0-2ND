#ifndef MEMORY_MANAGER_SERVICE_H
#define MEMORY_MANAGER_SERVICE_H

#include <grpcpp/grpcpp.h>
#include "memory_manager.grpc.pb.h"  // Define la clase memory::MemoryManager

// Declaración de la clase
class MemoryManagerServiceImpl final : public memory::MemoryManager::Service {
public:
    grpc::Status Create(grpc::ServerContext* context,
                        const memory::CreateRequest* request,
                        memory::CreateResponse* response) override;

    // Aquí puedes declarar otros métodos del servicio...
};

#endif // MEMORY_MANAGER_SERVICE_H
