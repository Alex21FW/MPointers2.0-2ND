#include "memory_manager_service.h"
#include <iostream>

grpc::Status MemoryManagerServiceImpl::Create(
    grpc::ServerContext* context,
    const memory::CreateRequest* request,
    memory::CreateResponse* response) {

    std::cout << "Cliente conectado, retornando mensaje de conexión" << std::endl;
    response->set_id(0);
    response->set_mensaje("Conectado al servidor");
    return grpc::Status::OK;
}
