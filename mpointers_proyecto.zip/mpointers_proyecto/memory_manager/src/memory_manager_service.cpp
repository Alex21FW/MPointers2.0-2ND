#include "memory_manager_service.h"
#include <iostream>
#include <mutex>

std::mutex memory_mutex; // Para concurrencia

// Método Create
grpc::Status MemoryManagerServiceImpl::Create(grpc::ServerContext* context,
    const memory::CreateRequest* request, memory::CreateResponse* response) {

    std::lock_guard<std::mutex> lock(memory_mutex);

    MemoryBlock block;
    block.id = next_id_++;
    block.size = request->size();
    block.type = request->type();
    block.data = "";  // Inicialmente vacío
    block.ref_count = 1;

    memory_blocks_[block.id] = block;

    response->set_id(block.id);
    response->set_mensaje("Bloque creado correctamente.");
    return grpc::Status::OK;
}

// Método Set
grpc::Status MemoryManagerServiceImpl::Set(grpc::ServerContext* context,
    const memory::SetRequest* request, memory::SetResponse* response) {

    std::lock_guard<std::mutex> lock(memory_mutex);

    auto it = memory_blocks_.find(request->id());
    if (it != memory_blocks_.end()) {
        if(request->value().size() > it->second.size) {
            response->set_success(false);
            response->set_mensaje("El valor excede el tamaño del bloque.");
        } else {
            it->second.data = request->value();
            response->set_success(true);
            response->set_mensaje("Valor asignado correctamente.");
        }
    } else {
        response->set_success(false);
        response->set_mensaje("Id no encontrado.");
    }

    return grpc::Status::OK;
}

// Método Get
grpc::Status MemoryManagerServiceImpl::Get(grpc::ServerContext* context,
    const memory::GetRequest* request, memory::GetResponse* response) {

    std::lock_guard<std::mutex> lock(memory_mutex);

    auto it = memory_blocks_.find(request->id());
    if (it != memory_blocks_.end()) {
        response->set_value(it->second.data);
        response->set_success(true);
        response->set_mensaje("Valor obtenido correctamente.");
    } else {
        response->set_success(false);
        response->set_mensaje("Id no encontrado.");
    }

    return grpc::Status::OK;
}

// Método IncreaseRefCount
grpc::Status MemoryManagerServiceImpl::IncreaseRefCount(grpc::ServerContext* context,
    const memory::RefCountRequest* request, memory::RefCountResponse* response) {

    std::lock_guard<std::mutex> lock(memory_mutex);

    auto it = memory_blocks_.find(request->id());
    if (it != memory_blocks_.end()) {
        it->second.ref_count++;
        response->set_ref_count(it->second.ref_count);
        response->set_success(true);
        response->set_mensaje("Referencia incrementada correctamente.");
    } else {
        response->set_success(false);
        response->set_mensaje("Id no encontrado.");
    }

    return grpc::Status::OK;
}

// Método DecreaseRefCount
grpc::Status MemoryManagerServiceImpl::DecreaseRefCount(grpc::ServerContext* context,
    const memory::RefCountRequest* request, memory::RefCountResponse* response) {

    std::lock_guard<std::mutex> lock(memory_mutex);

    auto it = memory_blocks_.find(request->id());
    if (it != memory_blocks_.end()) {
        if(it->second.ref_count > 0) {
            it->second.ref_count--;
        }

        response->set_ref_count(it->second.ref_count);
        response->set_success(true);

        if (it->second.ref_count == 0) {
            memory_blocks_.erase(it);
            response->set_mensaje("Referencia decrementada y bloque eliminado.");
        } else {
            response->set_mensaje("Referencia decrementada correctamente.");
        }
    } else {
        response->set_success(false);
        response->set_mensaje("Id no encontrado.");
    }

    return grpc::Status::OK;
}