#include "memory_manager_service.h"
#include <iostream>
#include <chrono>
#include <thread>
#include <algorithm>
#include <vector>
#include <mutex>
#include <cstring>

MemoryManagerServiceImpl::MemoryManagerServiceImpl(size_t total_memory_size)
    : memory_pool_(new char[total_memory_size]),
      total_memory_(total_memory_size),
      used_memory_(0),
      current_id_(0),
      running_(true) {

    gc_thread_ = std::thread(&MemoryManagerServiceImpl::GarbageCollector, this);
}

MemoryManagerServiceImpl::~MemoryManagerServiceImpl() {
    running_ = false;
    if (gc_thread_.joinable())
        gc_thread_.join();
    delete[] memory_pool_;
}

void MemoryManagerServiceImpl::GarbageCollector() {
    while (running_) {
        std::this_thread::sleep_for(std::chrono::seconds(10));

        std::lock_guard<std::mutex> lock(memory_mutex);
        bool removed = false;

        for (auto it = memory_blocks_.begin(); it != memory_blocks_.end();) {
            if (it->second.ref_count == 0) {
                std::cout << "[GC] Eliminando bloque id: " << it->second.id << std::endl;
                it = memory_blocks_.erase(it);
                removed = true;
            } else {
                ++it;
            }
        }

        if (removed) {
            Defragment();
        }
    }
}

void MemoryManagerServiceImpl::Defragment() {
    std::cout << "[GC] Desfragmentando memoria..." << std::endl;

    size_t offset = 0;
    std::vector<MemoryBlock> blocks;

    // Copia bloques a vector para ordenarlos por offset
    for (auto& pair : memory_blocks_)
        blocks.push_back(pair.second);

    std::sort(blocks.begin(), blocks.end(),
              [](const MemoryBlock& a, const MemoryBlock& b) {
                  return a.offset < b.offset;
              });

    for (auto& block : blocks) {
        if (block.offset != offset) {
            std::memmove(memory_pool_ + offset, memory_pool_ + block.offset, block.size);
            block.offset = offset;
        }
        offset += block.size;
        memory_blocks_[block.id] = block;
    }

    used_memory_ = offset;
    std::cout << "[GC] Memoria desfragmentada exitosamente." << std::endl;
}


// Método Create
grpc::Status MemoryManagerServiceImpl::Create(grpc::ServerContext* context,
    const memory::CreateRequest* request,
    memory::CreateResponse* response) {

    std::lock_guard<std::mutex> lock(memory_mutex);

    size_t size = request->size();
    const std::string& type = request->type();

    if (used_memory_ + size > total_memory_) {
        response->set_mensaje("Error: Memoria insuficiente.");
        response->set_id(-1);
        std::cerr << "[ERROR] Memoria insuficiente: solicitado (" << size << "), disponible (" 
                  << (total_memory_ - used_memory_) << ")" << std::endl;
        return grpc::Status::OK;
    }

    int new_id = ++current_id_;

    // Aquí correctamente insertas en memory_blocks_
    MemoryBlock new_block;
    new_block.id = new_id;
    new_block.size = size;
    new_block.type = type;
    new_block.data = "";  // Inicialmente vacío, el valor se setea con Set()
    new_block.ref_count = 1; // Inicializar ref_count a 1 al crear bloque
    new_block.offset = used_memory_;

    memory_blocks_[new_id] = new_block;

    used_memory_ += size; // Actualizas la memoria usada

    response->set_mensaje("Espacio creado correctamente.");
    response->set_id(new_id);

    std::cout << "[INFO] Espacio asignado (ID: " << new_id << "), tamaño: " << size << ", tipo: " << type << std::endl;

    return grpc::Status::OK;
}

// Método Set
grpc::Status MemoryManagerServiceImpl::Set(grpc::ServerContext* context, 
    const memory::SetRequest* request,
    memory::SetResponse* response) {

    std::lock_guard<std::mutex> lock(memory_mutex);

    int id = request->id();
    const std::string& value = request->value();

    auto it = memory_blocks_.find(id);
    if (it == memory_blocks_.end()) {
        response->set_mensaje("Error: ID inválido.");
        std::cerr << "[ERROR] Set falló: ID inválido (" << id << ")" << std::endl;
        return grpc::Status::OK;
    }

    if (value.size() > it->second.size) {
        response->set_mensaje("Error: tamaño de valor excede espacio reservado.");
        std::cerr << "[ERROR] Set falló: tamaño de valor excede (" << value.size() << ") > (" << it->second.size << ")" << std::endl;
        return grpc::Status::OK;
    }

    // Guardar el dato en el bloque
    it->second.data = value;

    size_t offset = it->second.offset; 
    memcpy(memory_pool_ + offset, value.data(), value.size());

    response->set_mensaje("Valor establecido correctamente.");
    std::cout << "[INFO] Valor establecido en ID: " << id << ", valor: " << value << std::endl;

    return grpc::Status::OK;
}

// Método Get
grpc::Status MemoryManagerServiceImpl::Get(grpc::ServerContext* context,
    const memory::GetRequest* request, memory::GetResponse* response) {

    std::lock_guard<std::mutex> lock(memory_mutex);

    int id = request->id();

    auto it = memory_blocks_.find(id);
    if (it == memory_blocks_.end()) {
        response->set_mensaje("Error: ID inválido.");
        response->set_value("");
        response->set_type("");
        std::cerr << "[ERROR] Get falló: ID inválido (" << id << ")" << std::endl;
        return grpc::Status::OK;
    }

    response->set_mensaje("Valor obtenido correctamente.");
    response->set_value(it->second.data);
    response->set_type(it->second.type);

    std::cout << "[INFO] Valor obtenido en ID: " << id
              << ", valor: " << it->second.data
              << ", tipo: " << it->second.type << std::endl;

    return grpc::Status::OK;
}

// Método IncreaseRefCount
grpc::Status MemoryManagerServiceImpl::IncreaseRefCount(grpc::ServerContext* context,
    const memory::RefCountRequest* request, memory::RefCountResponse* response) {

    std::lock_guard<std::mutex> lock(memory_mutex);

    auto it = memory_blocks_.find(request->id());
    if (it != memory_blocks_.end()) {
        it->second.ref_count++;
        response->set_ref_count(it->second.ref_count);
        response->set_success(true);
        response->set_mensaje("Referencia incrementada correctamente.");
    } else {
        response->set_success(false);
        response->set_mensaje("Id no encontrado.");
    }

    return grpc::Status::OK;
}

// Método DecreaseRefCount
grpc::Status MemoryManagerServiceImpl::DecreaseRefCount(grpc::ServerContext* context,
    const memory::RefCountRequest* request, memory::RefCountResponse* response) {

    std::lock_guard<std::mutex> lock(memory_mutex);

    auto it = memory_blocks_.find(request->id());
    if (it != memory_blocks_.end()) {
        if (it->second.ref_count > 0) {
            it->second.ref_count--;
        }

        response->set_ref_count(it->second.ref_count);
        response->set_success(true);

        if (it->second.ref_count == 0) {
            used_memory_ -= it->second.size;
            memory_blocks_.erase(it);
            response->set_mensaje("Referencia decrementada y bloque eliminado.");
        } else {
            response->set_mensaje("Referencia decrementada correctamente.");
        }
    } else {
        response->set_success(false);
        response->set_mensaje("Id no encontrado.");
    }

    return grpc::Status::OK;
}
