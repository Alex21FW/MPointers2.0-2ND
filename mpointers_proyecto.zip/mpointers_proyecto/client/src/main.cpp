#include <iostream>
#include <memory>
#include <string>
#include <grpcpp/grpcpp.h>
#include "memory_manager.grpc.pb.h"  // Asegúrate de que la ruta de los headers sea correcta

using grpc::Channel;
using grpc::ClientContext;
using grpc::Status;

class MemoryManagerClient {
public:
    MemoryManagerClient(std::shared_ptr<Channel> channel)
        : stub_(memory::MemoryManager::NewStub(channel)) {}

        void RunTest() {
            auto create_response = Create(64, "int");
            std::cout << "Bloque creado con ID: " << create_response.id() << std::endl;
    
            auto set_response = Set(create_response.id(), "42");
            std::cout << "Set status: " << set_response.mensaje() << std::endl;
    
            auto get_response = Get(create_response.id());
            std::cout << "Get value: " << get_response.value() << std::endl;
        }
    
        memory::CreateResponse Create(int size, const std::string& type) {
            memory::CreateRequest request;
            request.set_size(size);
            request.set_type(type);
    
            memory::CreateResponse response;
            ClientContext context;
    
            Status status = stub_->Create(&context, request, &response);
            if (!status.ok()) {
                std::cerr << "Create failed: " << status.error_message() << "\n";
            }
            return response;
        }
    
        memory::SetResponse Set(int id, const std::string& value) {
            memory::SetRequest request;
            request.set_id(id);
            request.set_value(value);
    
            memory::SetResponse response;
            ClientContext context;
    
            Status status = stub_->Set(&context, request, &response);
            if (!status.ok()) {
                std::cerr << "Set failed: " << status.error_message() << "\n";
            }
            return response;
        }
    
        memory::GetResponse Get(int id) {
            memory::GetRequest request;
            request.set_id(id);
    
            memory::GetResponse response;
            ClientContext context;
    
            Status status = stub_->Get(&context, request, &response);
            if (!status.ok()) {
                std::cerr << "Get failed: " << status.error_message() << "\n";
            }
            return response;
        }
    
    private:
        std::unique_ptr<memory::MemoryManager::Stub> stub_;
    };

    int main(int argc, char** argv) {
        MemoryManagerClient client(grpc::CreateChannel(
            "localhost:50051", grpc::InsecureChannelCredentials()));
    
        client.RunTest();
    
        return 0;
    }
