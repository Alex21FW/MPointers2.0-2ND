#include <iostream>
#include <memory>
#include <grpcpp/grpcpp.h>
#include "memory_manager.grpc.pb.h"  // Asegúrate de que la ruta de los headers sea correcta

using grpc::Channel;
using grpc::ClientContext;
using grpc::Status;

class MemoryManagerClient {
public:
    MemoryManagerClient(std::shared_ptr<Channel> channel)
        : stub_(memory::MemoryManager::NewStub(channel)) {}

    std::string Create(int size, const std::string& type) {
        // Prepara la solicitud y la respuesta
        memory::CreateRequest request;
        request.set_size(size);
        request.set_type(type);

        memory::CreateResponse response;
        ClientContext context;

        // Llama al método remoto
        Status status = stub_->Create(&context, request, &response);
        if (status.ok()) {
            return response.mensaje();  // suponiendo que agregaste el campo "mensaje" en el .proto
        } else {
            return "Error: " + status.error_message();
        }
    }

private:
    std::unique_ptr<memory::MemoryManager::Stub> stub_;
};

int main(int argc, char** argv) {
    // Conecta al servidor en localhost:50051
    MemoryManagerClient client(grpc::CreateChannel("localhost:50051", grpc::InsecureChannelCredentials()));

    // Realiza una petición de ejemplo
    std::string respuesta = client.Create(1024, "int");
    std::cout << "Respuesta del servidor: " << respuesta << std::endl;

    return 0;
}
